#include "mcc_generated_files/system/system.h"
#include "dmx.h"

uint8_t colors[3];
uint8_t idx = 0;

void UART1_Overflow(void){ // caused by RXFOIF
    printf("Overflow occurred\n");
    U1ERRIRbits.RXFOIF = 0;
}

void UART1_FramingError(void){ // caused by PIR4.U1EIF
    if (U1ERRIRbits.RXBKIF) // break received, thus beginning of transmission
    {
        U1ERRIRbits.RXBKIF = 0;
        idx = 0; // reset index
    }
}

void UART1_RX_Complete(void){ // caused by PIR4.U1RXIF
    uint8_t value  = UART1_Read();
    switch(idx){
        case 0:
            // throw away start code
            break;
        case 1:
            colors[0] = value;
            break;
        case 2:
            colors[1] = value;
            break;
        case 3:
            colors[2] = value;
            break;
    }
    idx++;
    printf("%x, %x, %x\n", colors[0], colors[1], colors[2]);
    PIR4bits.U1RXIF = 0; // interrupt has been serviced
}

void DMX_Initialize(void){
    // Disable interrupts before changing states
    PIE4bits.U1RXIE = 0; // Receive interrupt disable
    UART1_RxInterruptHandler = UART1_ReceiveISR; 
    PIE4bits.U1EIE = 0; // Framing error interrupt disable
    UART1_ErrorInterruptHandler = UART1_ErrorISR;
    PIE4bits.U1IE = 0; /// disable UART1 interrupts
    UART1_GeneralInterruptHandler = UART1_GeneralISR; // (used for wake up interrupt))
    
    // Receive register
    U1RXB = 0x0; 
    // UART Receive checksum disable
    U1RXCHK = 0x0; 
    //Transmit buffer disable
    U1TXB = 0x0; 
    // UART Transmit checksum disable
    U1TXCHK = 0x0; 
    
    U1P1 =  0x0; // bytes to transmit between Start Code and automatic Break generation
    U1P2 = BYTE_NUM; // first address of receive block
    U1P3 = BYTE_NUM + NUM_BYTES-1; // last address of receive block
    
    // BRGS high speed; MODE DMX mode; RXEN enabled; TXEN disabled; ABDEN disabled; 
    U1CON0 = 0x9A;
    //SENDB disabled; BRKOVR disabled; RXBIMD Set RXBKIF on rising RX input; WUE disabled; ON enabled; 
    U1CON1 = 0x80;
    // TXPOL not inverted; FLO off; C0EN Checksum Mode 0; RXPOL not inverted; RUNOVF RX input shifter stops all activity; STP Transmit 2Stop bit, receiver verifies first Stop bit; 
    U1CON2 = 0x20;

    // Baud = [Fosc*(1+(BRGS*3)]/[(16*(BRG+1))] (Fosc = 32Mhz)
    // BRGL 20; 
    U1BRGL = 0x3F;
    // BRGH 0; 
    U1BRGH = 0x00;

    //TXBE empty; STPMD in middle of first Stop bit; TXWRE No error; 
    U1FIFO = 0x20;

    //ABDIE disabled; ABDIF Auto-baud not enabled or not complete; WUIF WUE not enabled by software; 
    U1UIR = 0x0; 
    U1ERRIR = 0x80;    
    U1ERRIE = 0x06;
     
    // set RX pin = RC1
    U1RXPPSbits.PORT = 0b010; // PORT C (A=0, B=1, C=2)
    U1RXPPSbits.PIN = 0b001; // pin 1
    ANSELCbits.ANSELC1 = 0; // input pin bit    
        
    PIE4bits.U1IE = 1; // Enable UART interrupts
    PIE4bits.U1EIE = 1; // Framing error interrupt enable
    PIE4bits.U1RXIE = 1; // Enable Receive interrupts
}
