
#define BYTE_NUM 1
#define NUM_BYTES 3

void UART1_Overflow(void); // caused by RXFOIF
void UART1_FramingError(void); // caused by PIR4.U1EIF
void UART1_RX_Complete(void); // caused by PIR4.U1RXIF
void DMX_Initialize(void);
